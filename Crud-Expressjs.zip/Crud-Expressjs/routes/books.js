const ex=require("express")
const {route} =require("express/lib/application")
const Books=require("../models/book")
const router=ex.Router()

//creating the router


//get all the books

router.get("/",async(req,res)=>{
   try{
   const books = await Books.find()
   res.json(books)

   }catch(err){

   }
});


// get single books

router.get("/:booksId",async(req,res)=>{
    const booksId=req.params.booksId;
    try{
        const c=await Books.findById(booksId);
        res.json(c);
    }catch(error){
        res.json(error);
    }
});

//create 
router.post("/" ,async(req,res)=>{

  const books=await Books.create(req.body);
  res.json(books)

});

//delete

router.delete("/",async(req,res)=>{
    try{


    await Books.delete({"_id":req.params.booksId})
    res.status(200).json({
        message:"done",
    })
    }catch(error){
        res.json(error);
    }
})

//update book
router.put("/:booksId",(req,res)=>{
    const booksId=req.params.booksId;
    try{
       const books= Books.updateOne({
            "_id":booksId
        },
        req.body
        )
        res.json(books)
    }catch(error){
 res.json(error)
    }
})


module.exports=router