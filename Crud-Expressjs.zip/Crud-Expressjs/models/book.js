const mongoose=require("mongoose")

const Books=mongoose.Schema({
    title:{
        type:String,
        require:true
    },
    content:{
        type:String ,
        require:true
    },

    pages:{
        type:String,
        require:true
    },
    active:Boolean
});


module.exports=mongoose.model("Books",Books)