const express=require("express")



const app=express()

const booksrouter=require("./routes/books")
const bodyparser=require("body-parser")
require("dotenv").config()
const mongoose=require('mongoose')
app.use(bodyparser.json())
app.use("/apis/v1/books",booksrouter)



mongoose.connect(process.env.DB_CONNECTION_URL)
app.listen(process.env.PORT,()=>{
    console.log("Server is start");
})